from random import *
import speech_recognition as sr
from gtts import gTTS
import pyglet
import time
from timeit import default_timer as timer
import os
from w2n_k import *

r = sr.Recognizer()


def how_much():
    r0 = sr.Recognizer()
    with sr.Microphone(sample_rate=44100, chunk_size=700) as num:
        how_much_play = r0.listen(num)

    try:
        text_num = r0.recognize_google(how_much_play)
        text_num = korean_pron(text_num)
        print(text_num)
        valid = [str(i) for i in range(0, 11)]
        if text_num in valid:
            how_much_play_pro = int(text_num)
            return how_much_play_pro
        else:
            print("인식 범위를 벗어났네요. 다시 말해주세요.")
            make_words_speech("인식 범위를 벗어났네요. 다시 말해주세요.", mp3_file='')
            return how_much()

    except sr.UnknownValueError:
        print("인식이 안 되네요. 다시 말해 주세요")
        make_words_speech("인식이 안 되네요. 다시 말해 주세요 ", mp3_file='')
        speech_func(mp3_file=str(''))
        return how_much()


def make_mp3_file(mp3_file):
        mp3_file = mp3_file + '.wav'
        return str(mp3_file)
# make .mp3 file


def speech_func(mp3_file):
    mp3_file = make_mp3_file(mp3_file)
    mp3_file = './' + mp3_file


def make_words_speech(words, mp3_file):
        mp3_file = make_mp3_file(mp3_file)
        mp3_file = "./" + mp3_file
        label = words
        tts = gTTS(label, lang='ko')
        tts.save(mp3_file)
        music = pyglet.media.load(mp3_file, streaming=False)
        music.play()
        time.sleep(music.duration)


def voice():
    r = sr.Recognizer()
    with sr.Microphone(sample_rate=44100, chunk_size=700) as source:
        audio = r.listen(source, timeout=None)


    try:
        text = r.recognize_google(audio)
        text = korean_pron(text)
        print(text)
        valid = [str(i) for i in range(-1000000, 1000000)]
        if text in valid:
            num_text = int(text)
            return num_text

    except sr.UnknownValueError:
        print("인식이 안 되네요. 다시 말해 주세요")
        make_words_speech("인식이 안 되네요. 다시 말해 주세요 ", mp3_file='')
        speech_func(mp3_file=str(''))
        return voice()


def Q1(num1, num2, signal):
    question = num1 + num2
    print(str(num1) + "+" + str(num2) + "=?")
    make_words_speech("{} 더하기 {} {}".format(num1, num2, signal), mp3_file='')
    answer = voice()
    if int(question) == answer:
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q2(num1, num2, signal):
    question = num1 - num2
    print(str(num1) + "-" + str(num2) + "=?")
    make_words_speech("{} 빼기 {} {}".format(num1, num2, signal), mp3_file='')
    answer = voice()
    if int(question) == answer:
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q3(num1, num2, signal):
    question = num1 * num2
    print(str(num1) + "*" + str(num2) + "=?")
    make_words_speech("{} 곱하기 {} {}".format(num1, num2, signal), mp3_file='')
    answer = voice()
    if int(question) == answer:
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q4(num1, num2, signal):
    question = num1 / num2
    print(str(num1) + "/" + str(num2) + "=?")
    make_words_speech("{} 나누기 {} {}".format(num1, num2, signal), mp3_file='')
    answer = voice()
    if int(question) == answer:
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


# ---------몇 번 실행할 지를 사용자가 입력하게 하는 경우---------#

print("몇 번 실행하시겠어요? 최대 실행 횟수는 10번입니다.")
make_words_speech("몇 번 실행하시겠어요? 최대 실행 횟수는 열번입니다.", mp3_file='')

play_time = how_much()

print("이 게임은 처음 선택하신 횟수만큼 진행되며, 나누기의 경우 소수점을 제외한 정수 부분만 말해주시면 됩니다.")
make_words_speech("이 게임은, 처음 선택하신 횟수만큼 진행되며, 나누기의 경우, 소수점을 제외한, 정수 부분만 말해주시면 됩니다.", mp3_file='')

print("그럼 시작하겠습니다.")
make_words_speech("그럼 시작하겠습니다.", mp3_file='')

for i in range(play_time):
    x = randint(4, 4)
    num1 = randint(0, 10)
    num2 = randint(0, 10)
    if (x == 4) and (num2 == 0):
        num2 = randint(1, 10)

    if (num2 % 10) == 1 or (num2 % 10) == 3 or (num2 % 10) == 6 or (num2 % 10) == 7 or (num2 % 10) == 8 or (num2 % 10) == 0:
        signal = "은?"
    elif (num2 % 10) == 2 or (num2 % 10) == 4 or (num2 % 10) == 5 or (num2 % 10) == 9:
        signal = "는?"

    if x == 1:
        Q1(num1, num2, signal)
    elif x == 2:
        Q2(num1, num2, signal)
    elif x == 3:
        Q3(num1, num2, signal)
    elif x == 4:
        Q4(num1, num2, signal)

print("수고하셨습니다")
make_words_speech("수고하셨습니다", mp3_file='')