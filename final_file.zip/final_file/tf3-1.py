from random import *
import speech_recognition as sr
from gtts import gTTS
import pyglet
import time
from w2n_k import *

r = sr.Recognizer()


def how_much():
    r0 = sr.Recognizer()
    with sr.Microphone(sample_rate=44100, chunk_size=700) as num:
        how_much_play = r0.listen(num)

    try:
        text_num = r0.recognize_google(how_much_play)
        text_num = korean_pron(text_num)
        print(text_num)
        valid = [str(i) for i in range(0, 11)]
        if text_num in valid:
            how_much_play_pro = int(text_num)
            return how_much_play_pro
        else:
            print("인식 범위를 벗어났네요. 다시 말해주세요.")
            make_words_speech("인식 범위를 벗어났네요. 다시 말해주세요.", mp3_file='')
            return how_much()

    except sr.UnknownValueError:
        print("인식이 안 되네요. 다시 말해 주세요")
        make_words_speech("인식이 안 되네요. 다시 말해 주세요 ", mp3_file='')
        speech_func(mp3_file=str(''))
        return how_much()


def make_mp3_file(mp3_file):
        mp3_file = mp3_file + '.wav'
        return str(mp3_file)
# make .mp3 file


def speech_func(mp3_file):
    mp3_file = make_mp3_file(mp3_file)
    mp3_file = './' + mp3_file


def make_words_speech(words, mp3_file):
        mp3_file = make_mp3_file(mp3_file)
        mp3_file = "./" + mp3_file
        label = words
        tts = gTTS(label, lang='ko')
        tts.save(mp3_file)
        music = pyglet.media.load(mp3_file, streaming=False)
        music.play()
        time.sleep(music.duration)


def voice():
    r = sr.Recognizer()
    with sr.Microphone(sample_rate=44100, chunk_size=700) as source:
        audio = r.listen(source, timeout=None)

    try:
        text = r.recognize_google(audio)
        text = korean_pron(text)
        print(text)
        valid = [str(i) for i in range(-10000, 30000)]
        if text in valid:
            num_text = int(text)
            return num_text

    except sr.UnknownValueError:
        print("인식이 안 되네요. 다시 말해 주세요")
        make_words_speech("인식이 안 되네요. 다시 말해 주세요 ", mp3_file='')
        speech_func(mp3_file=str(''))
        return voice()


def Q1():
    n1 = 2 * randint(2, 4)
    n2 = randint(1, 5)
    if n1 == 4:
        wd = '사'
    elif n1 == 6:
        wd = '육'
    elif n1 == 8:
        wd = '팔'
    if n1 == 4:
        question = 6*n2
    elif n1 == 6:
        question = 12*n2
    elif n1 == 8:
        question = 12*n2
    print("한 변의 길이가 {}인 정{}면체가 있습니다. 이 입체도형의 모서리의 길이의 총 합은 얼마입니까?".format(n2, wd))
    make_words_speech("한 변의 길이가, {}인, 정 {}면체가 있습니다. 이 입체도형의 모서리의 길이의 총 합은 얼마입니까?".format(n2, wd), mp3_file='')

    answer = voice()
    if int(question) == answer:  # question(문제의 정답) == answer(음성인식으로 받아들인 값)
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q2 ():
    n1 = randint(1, 5)
    question = 6 * n1 * n1
    print("한 변의 길이가 {}인 정육면체가 있습니다. 이 입체도형의 겉넓이는 얼마입니까?".format(n1))
    make_words_speech("한 변의 길이가, {}인, 정육면체가 있습니다. 이 입체도형의 겉넓이는 얼마입니까?".format(n1), mp3_file='')

    answer = voice()
    if int(question) == answer:
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q3():
    n1 = randint(1, 5)
    n2 = randint(1, 5)
    question = n1 * n2
    print("밑변의 길이가 {}, 높이가 {}인 평행사변형이 있습니다. 이 도형의 넓이는 얼마입니까?".format(n1, n2))
    make_words_speech("밑변의 길이가 {}, 높이가 {}인, 평행사변형이 있습니다. 이 도형의 넓이는 얼마입니까?".format(n1, n2), mp3_file='')

    answer = voice()
    if int(question) == answer:
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q4():
    n1 = randint(1, 5)
    n2 = randint(1, 5)
    question = n1 * n2
    print("가로의 길이가 {}, 세로가 {}인 직사각형이 있습니다. 이 도형의 넓이는 얼마입니까?".format(n1, n2))
    make_words_speech("가로의 길이가 {}, 세로가 {}인, 직사각형이 있습니다. 이 도형의 넓이는 얼마입니까?".format(n1, n2), mp3_file='')
    answer = voice()
    if int(question) == answer:  # question(문제의 정답) == answer(음성인식으로 받아들인 값)
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q5():
    n1 = randint(1, 5)
    n2 = randint(1, 5)
    n3 = 2 * randint(1, 3)
    question = ((n1 + n2) * n3) / 2
    print("윗변의 길이가 {}, 밑변의 길이가 {}, 높이가 {}인 사다리꼴이 있습니다. 이 도형의 넓이는 얼마입니까?".format(n1, n2, n3))
    make_words_speech("윗변의 길이가 {}, 밑변의 길이가 {}, 높이가 {}인, 사다리꼴이 있습니다. 이 도형의 넓이는 얼마입니까?".format(n1, n2, n3),mp3_file='')
    answer = voice()

    if int(question) == answer:  # question(문제의 정답) == answer(음성인식으로 받아들인 값)
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')



def Q6():
    n1 = randint(1, 5)
    question = n1 * n1 * 3
    print("반지름의 길이가 {}인 원이 있습니다. 원주율을 3이라고 할 때, 원의 넓이는 얼마입니까?".format(n1))
    make_words_speech("반지름의 길이가 {}인, 원이 있습니다. 원주율을 3이라고 할 때, 원의 넓이는 얼마입니까?".format(n1),
                      mp3_file='')
    answer = voice()
    if int(question) == answer:  # question(문제의 정답) == answer(음성인식으로 받아들인 값)
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q7():
    n1 = randint(1, 5)
    question = 2 * n1 * 3
    print("반지름의 길이가 {}인 원이 있습니다. 원주율을 3이라고 할 때, 원의 둘레는 얼마입니까?".format(n1))
    make_words_speech("반지름의 길이가 {}인, 원이 있습니다. 원주율을 3이라고 할 때, 원의 둘레는 얼마입니까?".format(n1),
                      mp3_file='')
    answer = voice()
    if int(question) == answer:
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q8():
    n1 = randint(1, 8)
    question = 10000 - (1200*n1)
    print("준형이는 10000원을 가지고 있습니다. 이 돈을 가지고, 카페에 가서 1200원 짜리 아메리카노를 {}개 사고 거스름돈을 받았습니다. 준형이가 받은 거스름돈은 얼마입니까?".format(n1))
    make_words_speech("준형이는 10000원을 가지고 있습니다. 이 돈을 가지고, 카페에 가서, 1200원 짜리 아메리카노를 {}개 사고, 거스름돈을 받았습니다. 준형이가 받은 거스름돈은 얼마입니까?".format(n1), mp3_file='')

    answer = voice()
    if int(question) == answer:  # question(문제의 정답) == answer(음성인식으로 받아들인 값)
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q9():
    n1 = randint(1, 6)
    n2 = randint(1, 3)
    question = 1200 * n1 + 1000 * n2
    print("성재는 편의점에서 1200원짜리 컵라면 {}개와, 1000원짜리 바나나 우유 {}개를 샀습니다. 성재는 얼마를 내야 합니까?".format(n1, n2))
    make_words_speech("성재는 편의점에서 1200원짜리 컵라면 {}개와, 1000원짜리 바나나 우유{}개를, 샀습니다. 성재는 얼마를 내야 합니까?".format(n1, n2),
                      mp3_file='')

    answer = voice()
    if int(question) == answer:  # question(문제의 정답) == answer(음성인식으로 받아들인 값)
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


def Q10():
    n1 = 100 * randint(1, 4)
    question = 25
    print("한빈이는 {}제곱미터의 텃밭이 있습니다. 텃밭의 2분의 1에는 상추를 심고, 나머지의 2분의 1에는 깻잎을 심고, 남은 부분에는 매실을 심으려고 합니다. 매실을 심은 부분의 넓이는 얼마입니까?".format(n1))
    make_words_speech("한빈이는"+str(n1)+"제곱미터의 텃밭이 있습니다. 텃밭의 2분에 1에는, 상추를 심고, 나머지의 2분에 1에는, 깻잎을 심고. 남은 부분에는, 매실을 심으려고 합니다. 매실을 심은 부분의 넓이는, 얼마입니까?",
                      mp3_file='')

    answer = voice()
    if int(question) == answer:  # question(문제의 정답) == answer(음성인식으로 받아들인 값)
        print("정답입니다.")
        make_words_speech("정답입니다.", mp3_file='')
    else:
        print("틀렸습니다.")
        make_words_speech("틀렸습니다.", mp3_file='')


# 실제 실행 부분! main()
print("몇 번 실행하시겠어요? 최대 실행 횟수는 10번입니다.")
make_words_speech("몇 번 실행하시겠어요? 최대 실행 횟수는, 열번입니다.", mp3_file='')

play_time = how_much()

print("그럼 시작하겠습니다.")
make_words_speech("그럼, 시작하겠습니다.", mp3_file='')

for i in range(play_time):
    x = randint(1, 10)
    if x == 1:
        Q1()
    elif x == 2:
        Q2()
    elif x == 3:
        Q3()
    elif x == 4:
        Q4()
    elif x == 5:
        Q5()
    elif x == 6:
        Q6()
    elif x == 7:
        Q7()
    elif x == 8:
        Q8()
    elif x == 9:
        Q9()
    elif x == 10:
        Q10()

print("수고하셨습니다")
make_words_speech("수고하셨습니다", mp3_file='')